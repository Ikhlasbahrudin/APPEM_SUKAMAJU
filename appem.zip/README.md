login masyarakat :bahrudin
password         :1234

login pertugas/admin  :admin 
password              :admin 

petugas               : petugas
password              :petugas 
